package com.example.ma_premiere_application_android;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    DecimalFormat df = new DecimalFormat("0.00"); // import java.text.DecimalFormat;

    // Variables pour vos revenus mensuels
    private EditText txt_salaire_mensuel;
    private String salaire_mensuel_string;
    private double salaire_mensuel_double;

    private EditText txt_pension_alimentaire;
    private String pension_alimentaire_string;
    private double pension_alimentaire_double;

    private EditText txt_autre_revenus;
    private String autre_revenus_string;
    private double autre_revenus_double;

    private double total_revenus_mensuels;


    // Variables vos paiements de remboursement
    private EditText txt_paiement_hypothecaire;
    private String paiement_hypothecaire_string;
    private double paiement_hypothecaire_double;

    private EditText txt_paiement_mensuel_automobile;
    private String paiement_mensuel_automobile_string;
    private double paiement_mensuel_automobile_double;

    private  EditText txt_pret_personnel;
    private  String pret_personnel_string;
    private double pret_personnel_double;

    private  EditText txt_pret_cartes_credits;
    private String pret_cartes_credits_string;
    private double pret_cartes_credits_double;

    private  EditText txt_pret_etudiant;
    private  String pret_etudiant_string;
    private double pret_etudiant_double;

    private  EditText txt_pret_alimentaire;
    private String pret_alimentaire_string;
    private double pret_alimentaire_double;

    private EditText txt_pret_divers_1;
    private String pret_divers_1_string;
    private double pret_divers_1_double;

    private  EditText txt_pret_divers_2;
    private  String pret_divers_2_string;
    private double pret_divers_2_double;

    private  EditText txt_pret_divers_3;
    private  String pret_divers_3_string;
    private  double pret_divers_3_double;

    private double total_paiement_remboursement;

    private double ratio_dettes;


    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    public void Calculer(View view)
    {
        ((Button)findViewById(R.id.calculer)).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                try{

                    // Vos revenus mensuels
                    txt_salaire_mensuel = (EditText)findViewById(R.id.salaire_mensuel);
                    salaire_mensuel_string = txt_salaire_mensuel.getText().toString();
                    salaire_mensuel_double = Double.valueOf(salaire_mensuel_string);

                    txt_pension_alimentaire = (EditText)findViewById(R.id.pension_alimentaire_recu);
                    pension_alimentaire_string = txt_pension_alimentaire.getText().toString();
                    pension_alimentaire_double = Double.valueOf(pension_alimentaire_string);

                    txt_autre_revenus = (EditText)findViewById(R.id.autre_revenu_mensuel);
                    autre_revenus_string = txt_autre_revenus.getText().toString();
                    autre_revenus_double = Double.valueOf(autre_revenus_string);

                    total_revenus_mensuels = autre_revenus_double + pension_alimentaire_double + salaire_mensuel_double;

                    ((TextView)findViewById(R.id.total_revenus_mensuels)).setText(df.format(total_revenus_mensuels) + " $");

                    // Vos paiements de remboursement
                    txt_paiement_hypothecaire = (EditText)findViewById(R.id.paiement_hypothecaire);
                    paiement_hypothecaire_string = txt_paiement_hypothecaire.getText().toString();
                    paiement_hypothecaire_double = Double.valueOf(paiement_hypothecaire_string);

                    txt_paiement_mensuel_automobile = (EditText)findViewById(R.id.paiement_mensuel_automobile);
                    paiement_mensuel_automobile_string = txt_paiement_mensuel_automobile.getText().toString();
                    paiement_mensuel_automobile_double = Double.valueOf(paiement_mensuel_automobile_string);

                    txt_pret_personnel = (EditText)findViewById(R.id.pret_personnel);
                    pret_personnel_string = txt_pret_personnel.getText().toString();
                    pret_personnel_double = Double.valueOf(pret_personnel_string);

                    txt_pret_cartes_credits = (EditText)findViewById(R.id.pret_cartes_credits);
                    pret_cartes_credits_string = txt_pret_cartes_credits.getText().toString();
                    pret_cartes_credits_double = Double.valueOf(pret_cartes_credits_string);

                    txt_pret_etudiant = (EditText)findViewById(R.id.pret_etudiant);
                    pret_etudiant_string = txt_pret_etudiant.getText().toString();
                    pret_etudiant_double = Double.valueOf(pret_etudiant_string);

                    txt_pret_alimentaire = (EditText)findViewById(R.id.pret_alimentaire);
                    pret_alimentaire_string = txt_pret_alimentaire.getText().toString();
                    pret_alimentaire_double = Double.valueOf(pret_alimentaire_string);

                    txt_pret_divers_1 = (EditText)findViewById(R.id.pret_divers_1);
                    pret_divers_1_string = txt_pret_divers_1.getText().toString();
                    pret_divers_1_double = Double.valueOf(pret_divers_1_string);

                    txt_pret_divers_2 = (EditText)findViewById(R.id.pret_divers_2);
                    pret_divers_2_string = txt_pret_divers_2.getText().toString();
                    pret_divers_2_double = Double.valueOf(pret_divers_2_string);

                    txt_pret_divers_3 = (EditText)findViewById(R.id.pret_divers_3);
                    pret_divers_3_string = txt_pret_divers_3.getText().toString();
                    pret_divers_3_double = Double.valueOf(pret_divers_3_string);

                    total_paiement_remboursement = paiement_hypothecaire_double + paiement_mensuel_automobile_double + pret_personnel_double + pret_cartes_credits_double + pret_etudiant_double + pret_alimentaire_double + pret_divers_1_double + pret_divers_2_double + pret_divers_3_double;
                    ((TextView)findViewById(R.id.total_dettes)).setText(df.format(total_paiement_remboursement) + " $");

                    //Ratio d'endettement = (Total de vos dépenses / Total de vos revenus bruts) x 100

                    ratio_dettes = (total_paiement_remboursement / total_revenus_mensuels) * 100;
                    ((TextView)findViewById(R.id.ratio_dettes)).setText(df.format(ratio_dettes) + " %");

                }catch (Exception e)
                {
                    Toast.makeText(getApplicationContext(), "Veuillez remplir tous les champs avec des valeurs correctes",Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}
