package com.example.monpicerie;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView ListView;
    private String nomProd;
    private double prixProd;
    private ArrayList<String> tableauDeNomProd = new ArrayList<>();
    private ArrayList<String> total = new ArrayList<>();

    private RadioGroup radioGroup;
    private RadioButton radioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //radioGroup = findViewById(R.id.radioGroup);
    }

    // MyAllAction action = new MyAllAction();


    public void ajouter_au_panier(View view)
    {

        try {

            EditText edt1 = (EditText)findViewById(R.id.nom_du_produit);
            this.nomProd = edt1.getText().toString();

            EditText edt2 = (EditText)findViewById(R.id.prix_du_produit);
            String conv = edt2.getText().toString();
            this.prixProd = Double.parseDouble(conv);

            // Ajout du produit et du prix au tableau
            this.tableauDeNomProd.add(( "Nom : " + this.nomProd + "\n" + "Prix : " + this.prixProd) + " $");

            this.total.add(Double.toString(this.prixProd)); // Ajout du prix au tableau de prix

            Toast.makeText(getApplicationContext(),"Produit ajouté au panier",Toast.LENGTH_SHORT).show();

            edt1.setText(null);
            edt2.setText(null);

        }catch (Exception ex){

            Toast.makeText(getApplicationContext(),"Remplissez les champs avec de bonnes valeurs",Toast.LENGTH_SHORT).show();
        }



    }

    public void consultation(View view)
    {
         // Permet à une activité de demander la permission au système de lancer une activité
        Intent i = new Intent(this, Main2Activity.class);

        if(this.tableauDeNomProd.size() > 0 )
        {
            i.putExtra("data", tableauDeNomProd);
            i.putExtra("price", total);

            startActivity(i);
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Votre panier est encore vide",Toast.LENGTH_SHORT).show();
        }

    }


}
