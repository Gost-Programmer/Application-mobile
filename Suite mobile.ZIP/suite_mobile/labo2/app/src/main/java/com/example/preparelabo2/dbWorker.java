package com.example.preparelabo2;

import android.content.Context;
import android.os.AsyncTask;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.URL;

import androidx.appcompat.app.AlertDialog;

import java.net.HttpURLConnection;
import java.net.URLEncoder;

public  class dbWorker extends AsyncTask {
    private Context c;
    private AlertDialog ad;

    public dbWorker(Context c) {
        this.c= c;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        this.ad=new AlertDialog.Builder(this.c).create();
        this.ad.setTitle("Login Status");

    }
    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);
        this.ad.setMessage((String)o);
        this.ad.show();

    }





    @Override
    protected String doInBackground(Object[] param) {
        String cible= " http://192.168.0.110/android/utilisateur/login.php";
        try
        {
            URL url=new URL(cible);
            HttpURLConnection con=(HttpURLConnection)url.openConnection();
            con.setDoInput(true);
            con.setDoOutput(true);
            con.setRequestMethod("POST");

            OutputStream outs=con.getOutputStream();
            BufferedWriter butw= new BufferedWriter(new OutputStreamWriter(outs,"utf-8"));

            String msg= URLEncoder.encode("user","utf-8")+"="+
                    URLEncoder.encode((String)param[0],"utf-8")+
                    "&"+URLEncoder.encode("password","utf-8")+"="+
                    URLEncoder.encode((String)param[1],"utf-8");

            butw.write(msg);
            butw.flush();
            butw.close();
            outs.close();

            InputStream ins=con.getInputStream();
            BufferedReader bufr= new BufferedReader(new InputStreamReader(ins,"iso-8859-1"));
            String line;
            StringBuffer sbuff = new StringBuffer();

            while((line=bufr.readLine())!=null)
            {
                sbuff.append(line + "\n");
            }
            return  sbuff.toString();

        }catch(Exception ex)
        {
            return  ex.getMessage();
        }

    }
}



