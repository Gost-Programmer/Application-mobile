package com.example.preparelabo2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private EditText txtuser;
    private EditText txtpassword;
   // private Button btnLoginUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtuser=(EditText)findViewById(R.id.user);
        txtpassword=(EditText)findViewById(R.id.password);

      /*  btnLoginUser=(Button)findViewById(R.id.btnlogin);
        btnLoginUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName=MainActivity.this.txtuser.getText().toString();
                String userPw= MainActivity.this.txtpassword.getText().toString();

                dbWorker dbw=new dbWorker(MainActivity.this);
                dbw.execute(userName,userPw);
            }
        });*/
    }

    public void LoginUser(View v) {
        String userName=this.txtuser.getText().toString();
        String userPw= this.txtpassword.getText().toString();

        dbWorker dbw=new dbWorker(this);
        dbw.execute(userName,userPw);
    }
}