package com.example.tp3suite_dialog;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ProgressDialog progressD=new ProgressDialog(this);
        progressD.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressD.setButton(Dialog.BUTTON_NEGATIVE, "cancel", new
                DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        
                    }
                }
        );

    }
}