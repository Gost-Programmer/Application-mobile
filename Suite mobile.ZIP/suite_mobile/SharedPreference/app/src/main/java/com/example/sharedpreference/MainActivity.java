package com.example.sharedpreference;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button btnsauvegarder, btnrecupere;
    private EditText Cledonnee,Valeurdonnee,ClepourRecupere;
    private TextView ValeurRecuperee;

    //declaration du nom de preferstar
    private final String MyprefName="demoShardPref";

    @Override
    protected void onResume() {
        super.onResume();
        Log.i("lifeCycle","onResume");
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("lifeCycle","onStart");
    }

    @Override
   protected void onStop() {
        super.onStop();
       Log.i("lifeCycle","onStop");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.i("lifeCycle","onDestroy");
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.i("lifeCycle","onPause");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.i("lifeCycle","onRestart");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Cledonnee=(EditText)findViewById(R.id.texnom);
        Valeurdonnee=(EditText)findViewById(R.id.textprenom);
        ClepourRecupere=(EditText)findViewById(R.id.textcle);

        ValeurRecuperee=(TextView)findViewById(R.id.lblvaleur);

        btnsauvegarder=(Button)findViewById(R.id.btnajout);
        btnsauvegarder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences pref=getSharedPreferences(MyprefName, getApplicationContext().MODE_PRIVATE);

                //il faut un editeur de prefershared
                SharedPreferences.Editor editor=pref.edit();

                //SharedPreferences est pour stocker les données de type primitives
                //on passe les informations à la methode putString.
                editor.putString(Cledonnee.getText().toString(),Valeurdonnee.getText().toString());

                //Insertion des informations dans le SharedPreferences par deux methode
                // commit(tant que l'application ne fini pas de charger, l'ecran est bloqué et empeche a l'utilisateur de travailler).
                // et apply(laisse utilisateur travailler meme si cest pas chargé et que ca fait du travail en arrière)
                editor.apply();

            }
        });

        btnrecupere=(Button)findViewById(R.id.btnrecuperation);
        btnrecupere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences pref=getSharedPreferences(MyprefName, getApplicationContext().MODE_PRIVATE);
                ValeurRecuperee.setText(pref.getString(ClepourRecupere.getText().toString(),"n/a"));

            }
        });



    }
}